import CryptoJS from 'crypto-js';
import { hash } from './crypto';

interface StoredUser {
  username: string;
  passwordHash: string;
  salt: string;
  createdAt: number;
}

class AuthStorage {
  private static instance: AuthStorage;
  private users: Map<string, StoredUser> = new Map();
  private readonly storageKey = hash('toorsec_users_v1');
  private readonly encryptionKey = hash('toorsec_storage_key');

  private constructor() {
    this.loadUsers();
  }

  static getInstance(): AuthStorage {
    if (!AuthStorage.instance) {
      AuthStorage.instance = new AuthStorage();
    }
    return AuthStorage.instance;
  }

  private loadUsers() {
    try {
      const encryptedData = localStorage.getItem(this.storageKey);
      if (encryptedData) {
        const decrypted = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey).toString(CryptoJS.enc.Utf8);
        const data = JSON.parse(decrypted);
        this.users = new Map(Object.entries(data));
      }
    } catch (error) {
      console.error('Failed to load users');
      this.users = new Map();
    }
  }

  private saveUsers() {
    try {
      const data = Object.fromEntries(this.users);
      const encrypted = CryptoJS.AES.encrypt(
        JSON.stringify(data),
        this.encryptionKey
      ).toString();
      localStorage.setItem(this.storageKey, encrypted);
    } catch (error) {
      console.error('Failed to save users');
    }
  }

  private generateSalt(): string {
    return CryptoJS.lib.WordArray.random(128 / 8).toString();
  }

  private hashPassword(password: string, salt: string): string {
    return CryptoJS.PBKDF2(password, salt, {
      keySize: 512 / 32,
      iterations: 10000
    }).toString();
  }

  async register(username: string, password: string): Promise<boolean> {
    if (this.users.has(username)) {
      return false;
    }

    const salt = this.generateSalt();
    const passwordHash = this.hashPassword(password, salt);

    this.users.set(username, {
      username,
      passwordHash,
      salt,
      createdAt: Date.now()
    });

    this.saveUsers();
    return true;
  }

  async login(username: string, password: string): Promise<boolean> {
    const user = this.users.get(username);
    if (!user) {
      return false;
    }

    const passwordHash = this.hashPassword(password, user.salt);
    return passwordHash === user.passwordHash;
  }

  getUser(username: string): Omit<StoredUser, 'passwordHash' | 'salt'> | null {
    const user = this.users.get(username);
    if (!user) {
      return null;
    }

    return {
      username: user.username,
      createdAt: user.createdAt
    };
  }
}

export const authStorage = AuthStorage.getInstance();