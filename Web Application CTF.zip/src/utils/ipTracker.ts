import { UserAttempt, UserStats } from '../types';

class IPTracker {
  private attempts: UserAttempt[] = [];
  private stats: Map<string, UserStats> = new Map();

  async getClientIP(): Promise<string> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error('Failed to get IP:', error);
      return 'unknown';
    }
  }

  recordAttempt(ip: string, flagId: number, success: boolean) {
    const attempt: UserAttempt = {
      ip,
      timestamp: Date.now(),
      flagId,
      success
    };

    this.attempts.push(attempt);
    this.updateStats(attempt);
  }

  private updateStats(attempt: UserAttempt) {
    const existing = this.stats.get(attempt.ip) || {
      ip: attempt.ip,
      attempts: 0,
      solvedFlags: [],
      lastAttempt: 0
    };

    existing.attempts++;
    existing.lastAttempt = attempt.timestamp;

    if (attempt.success && !existing.solvedFlags.includes(attempt.flagId)) {
      existing.solvedFlags.push(attempt.flagId);
    }

    this.stats.set(attempt.ip, existing);
  }

  getStats(ip: string): UserStats | undefined {
    return this.stats.get(ip);
  }

  getAllStats(): UserStats[] {
    return Array.from(this.stats.values());
  }
}

export const ipTracker = new IPTracker();