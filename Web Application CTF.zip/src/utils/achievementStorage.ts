import { Achievement } from '../types';
import { encrypt, decrypt } from './crypto';

class AchievementStorage {
  private static instance: AchievementStorage;
  private readonly storageKey = 'toorsec_achievements';
  private achievements: Achievement[] = [];

  private constructor() {
    this.loadAchievements();
  }

  static getInstance(): AchievementStorage {
    if (!AchievementStorage.instance) {
      AchievementStorage.instance = new AchievementStorage();
    }
    return AchievementStorage.instance;
  }

  private loadAchievements() {
    try {
      const encrypted = localStorage.getItem(this.storageKey);
      if (encrypted) {
        const decrypted = decrypt(encrypted);
        this.achievements = JSON.parse(decrypted);
      }
    } catch (error) {
      console.error('Failed to load achievements');
      this.achievements = [];
    }
  }

  private saveAchievements() {
    try {
      const encrypted = encrypt(JSON.stringify(this.achievements));
      localStorage.setItem(this.storageKey, encrypted);
    } catch (error) {
      console.error('Failed to save achievements');
    }
  }

  addAchievement(achievement: Achievement) {
    if (!this.achievements.some(a => a.id === achievement.id)) {
      this.achievements.push(achievement);
      this.saveAchievements();
    }
  }

  getAllAchievements(): Achievement[] {
    return [...this.achievements];
  }

  getAchievementByUsername(username: string): Achievement | undefined {
    return this.achievements.find(a => a.username === username);
  }
}

export const achievementStorage = AchievementStorage.getInstance();