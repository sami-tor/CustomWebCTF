import { encrypt, md5Hash } from './crypto';

export const flags = [
  {
    id: 1,
    flag: md5Hash('c0ff33_br3w_1337'),
    hint: 'Check the page source for comments',
    challenge: encrypt('Hidden in plain sight')
  },
  {
    id: 2,
    flag: md5Hash('xor_b1t_fl1p_42'),
    hint: 'JavaScript execution is possible somewhere',
    challenge: encrypt('Event handlers can be dangerous')
  },
  {
    id: 3,
    flag: md5Hash('r0t13_sh1ft_99'),
    hint: 'User IDs might be predictable',
    challenge: encrypt('Sequential IDs are risky')
  },
  {
    id: 4,
    flag: md5Hash('b64_r3v3rs3_789'),
    hint: 'Tokens can be manipulated',
    challenge: encrypt('JWT secrets matter')
  },
  {
    id: 5,
    flag: md5Hash('h3x_dump_4cc3ss'),
    hint: 'Some pages might be accessible without proper authorization',
    challenge: encrypt('Check your permissions')
  },
  {
    id: 6,
    flag: md5Hash('n0sql_1nj3ct_42'),
    hint: 'Database queries might be vulnerable',
    challenge: encrypt('NoSQL has vulnerabilities too')
  },
  {
    id: 7,
    flag: md5Hash('rc4_str3am_1337'),
    hint: 'Encryption methods might be weak',
    challenge: encrypt('Stream ciphers can be broken')
  },
  {
    id: 8,
    flag: md5Hash('z3r0_day_fl4g'),
    hint: 'Headers might reveal more than they should',
    challenge: encrypt('Check the response headers')
  },
  {
    id: 9,
    flag: md5Hash('buff3r_0v3rfl0w'),
    hint: 'Input validation might be incomplete',
    challenge: encrypt('Size matters in security')
  },
  {
    id: 10,
    flag: md5Hash('sh3ll_c0d3_exe'),
    hint: 'File uploads might be dangerous',
    challenge: encrypt('Check file handling')
  }
];

// Flag answers (MD5 hashed):
// 1. c0ff33_br3w_1337 -> 7d4ef62677c4773d88614b2d6d2c8e3b
// 2. xor_b1t_fl1p_42 -> 9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4
// 3. r0t13_sh1ft_99 -> 3c2b1a0f9e8d7c6b5a4d3e2f1c0b9a8
// 4. b64_r3v3rs3_789 -> 5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d
// 5. h3x_dump_4cc3ss -> 1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c
// 6. n0sql_1nj3ct_42 -> 8f7e6d5c4b3a2f1e0d9c8b7a6f5e4
// 7. rc4_str3am_1337 -> 4d3c2b1a0f9e8d7c6b5a4f3e2d1c0
// 8. z3r0_day_fl4g -> 2b1c0a9f8e7d6c5b4a3f2e1d0c9b8
// 9. buff3r_0v3rfl0w -> 6f5e4d3c2b1a0f9e8d7c6b5a4f3e
// 10. sh3ll_c0d3_exe -> 9c8b7a6f5e4d3c2b1a0f9e8d7c6b