import { UserStats } from '../types';

class SessionManager {
  private static instance: SessionManager;
  private sessions: Map<string, {
    startTime: number;
    ip: string;
    stats: UserStats;
  }> = new Map();
  
  private constructor() {}

  static getInstance(): SessionManager {
    if (!SessionManager.instance) {
      SessionManager.instance = new SessionManager();
    }
    return SessionManager.instance;
  }

  createSession(ip: string, stats: UserStats): string {
    // Check if IP already has an active session
    for (const [sessionId, session] of this.sessions) {
      if (session.ip === ip) {
        return sessionId;
      }
    }

    const sessionId = crypto.randomUUID();
    this.sessions.set(sessionId, {
      startTime: Date.now(),
      ip,
      stats
    });
    return sessionId;
  }

  getSession(sessionId: string, ip: string): { valid: boolean; stats?: UserStats; timeRemaining?: number } {
    const session = this.sessions.get(sessionId);
    
    if (!session) {
      return { valid: false };
    }

    // Verify IP matches
    if (session.ip !== ip) {
      this.sessions.delete(sessionId);
      return { valid: false };
    }

    // Check session timeout (1 hour)
    const sessionAge = Date.now() - session.startTime;
    const timeRemaining = 60 * 60 * 1000 - sessionAge; // 1 hour in milliseconds

    if (timeRemaining <= 0) {
      this.sessions.delete(sessionId);
      return { valid: false };
    }

    return { 
      valid: true, 
      stats: session.stats,
      timeRemaining
    };
  }

  formatTimeRemaining(timeRemaining: number): string {
    const hours = Math.floor(timeRemaining / (60 * 60 * 1000));
    const minutes = Math.floor((timeRemaining % (60 * 60 * 1000)) / (60 * 1000));
    const seconds = Math.floor((timeRemaining % (60 * 1000)) / 1000);

    const parts = [];
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    parts.push(`${seconds}s`);

    return parts.join(' ');
  }

  updateSession(sessionId: string, stats: UserStats): void {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.stats = stats;
      this.sessions.set(sessionId, session);
    }
  }

  clearSession(sessionId: string): void {
    this.sessions.delete(sessionId);
  }
}

export const sessionManager = SessionManager.getInstance();