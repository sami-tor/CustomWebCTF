import CryptoJS from 'crypto-js';

const SECRET_KEY = 'th1s_1s_n0t_th3_fl4g';

export const encrypt = (text: string): string => {
  return CryptoJS.AES.encrypt(text, SECRET_KEY).toString();
};

export const decrypt = (ciphertext: string): string => {
  const bytes = CryptoJS.AES.decrypt(ciphertext, SECRET_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
};

export const md5Hash = (text: string): string => {
  return CryptoJS.MD5(text).toString();
};

export const hash = (text: string): string => {
  return CryptoJS.SHA256(text).toString();
};