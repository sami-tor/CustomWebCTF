export interface Flag {
  id: number;
  solved: boolean;
  hint?: string;
}

export interface FlagSubmission {
  flagId: number;
  answer: string;
}

export interface UserAttempt {
  ip: string;
  timestamp: number;
  flagId: number;
  success: boolean;
}

export interface UserStats {
  ip: string;
  attempts: number;
  solvedFlags: number[];
  lastAttempt: number;
}

export interface Achievement {
  id: string;
  username: string;
  completionDate: string;
  certificateId: string;
}