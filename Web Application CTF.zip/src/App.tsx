import React, { useState, useEffect } from 'react';
import { Flag } from './types';
import { FlagSubmission } from './components/FlagSubmission';
import { Shield, Activity, Home, LogIn, BookOpen, Flag as FlagIcon, Menu, X, Trophy } from 'lucide-react';
import { ipTracker } from './utils/ipTracker';
import { sessionManager } from './utils/sessionManager';
import { AuthForm } from './components/AuthForm';
import { HallOfFame } from './components/HallOfFame';
import { Achievement } from './types';
import { achievementStorage } from './utils/achievementStorage';

function App() {
  const [flags, setFlags] = useState<Flag[]>([]);
  const [userIP, setUserIP] = useState<string>('');
  const [userStats, setUserStats] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [sessionId, setSessionId] = useState<string>('');
  const [sessionExpired, setSessionExpired] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState<string>('');
  const [achievement, setAchievement] = useState<Achievement | null>(null);
  const [allAchievements, setAllAchievements] = useState<Achievement[]>([]);
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  useEffect(() => {
    // Load all achievements on mount
    setAllAchievements(achievementStorage.getAllAchievements());
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    const initializeSession = async () => {
      const ip = await ipTracker.getClientIP();
      setUserIP(ip);
      
      const stats = ipTracker.getStats(ip) || {
        ip,
        attempts: 0,
        solvedFlags: [],
        lastAttempt: Date.now()
      };
      
      const sid = sessionManager.createSession(ip, stats);
      setSessionId(sid);
      setUserStats(stats);

      // Check for achievement
      const existingAchievement = achievementStorage.getAchievementByUsername(username);
      if (existingAchievement) {
        setAchievement(existingAchievement);
      } else if (stats.solvedFlags.length === 10 && !achievement) {
        const newAchievement = {
          id: crypto.randomUUID(),
          username,
          completionDate: new Date().toISOString(),
          certificateId: crypto.randomUUID()
        };
        setAchievement(newAchievement);
        achievementStorage.addAchievement(newAchievement);
        setAllAchievements(achievementStorage.getAllAchievements());
        setCurrentPage('certificate');
      }

      // Update session timer every second
      const timerInterval = setInterval(() => {
        const { valid, timeRemaining } = sessionManager.getSession(sid, ip);
        if (!valid) {
          setSessionExpired(true);
          clearInterval(timerInterval);
        } else if (timeRemaining) {
          setTimeRemaining(sessionManager.formatTimeRemaining(timeRemaining));
        }
      }, 1000);

      return () => clearInterval(timerInterval);
    };

    initializeSession();
    setFlags([
      { id: 1, solved: false },
      { id: 2, solved: false },
      { id: 3, solved: false },
      { id: 4, solved: false },
      { id: 5, solved: false },
      { id: 6, solved: false },
      { id: 7, solved: false },
      { id: 8, solved: false },
      { id: 9, solved: false },
      { id: 10, solved: false }
    ]);
  }, [isAuthenticated, username]);

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUsername('');
    setAchievement(null);
    sessionManager.clearSession(sessionId);
  };

  if (!isAuthenticated) {
    return (
      <AuthForm 
        onAuth={(user) => {
          setIsAuthenticated(true);
          setUsername(user.username);
        }} 
      />
    );
  }

  if (sessionExpired) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="bg-gray-800 p-8 rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold mb-4">Session Expired</h2>
          <p className="text-gray-400 mb-4">Your session has expired. Please refresh the page to start a new session.</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }

  const handleFlagSolved = (flagId: number) => {
    const { valid, stats } = sessionManager.getSession(sessionId, userIP);
    
    if (!valid) {
      setSessionExpired(true);
      return;
    }

    ipTracker.recordAttempt(userIP, flagId, true);
    const updatedStats = ipTracker.getStats(userIP);
    
    setFlags(prevFlags =>
      prevFlags.map(flag =>
        flag.id === flagId ? { ...flag, solved: true } : flag
      )
    );
    
    setUserStats(updatedStats);
    sessionManager.updateSession(sessionId, updatedStats);

    // Check if all flags are solved
    if (updatedStats.solvedFlags.length === 10 && !achievement) {
      const newAchievement = {
        id: crypto.randomUUID(),
        username,
        completionDate: new Date().toISOString(),
        certificateId: crypto.randomUUID()
      };
      setAchievement(newAchievement);
      setCurrentPage('certificate');
    }
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return (
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Welcome to ToorSec CTF</h2>
            <p className="text-gray-400 mb-4">Test your skills against our most challenging web security puzzles.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">10 Challenges</h3>
                <p className="text-gray-400">Each more difficult than the last</p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">Real Vulnerabilities</h3>
                <p className="text-gray-400">Based on actual security flaws</p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">Track Progress</h3>
                <p className="text-gray-400">Monitor your success rate</p>
              </div>
            </div>
          </div>
        );
      case 'ctf':
        return (
          <div className="space-y-6">
            {flags.map((flag, index) => (
              <FlagSubmission
                key={flag.id}
                flag={flag}
                onSolve={handleFlagSolved}
                isLocked={index > 0 && !flags[index - 1].solved}
              />
            ))}
          </div>
        );
      case 'certificate':
        if (achievement) {
          return (
            <>
              <HallOfFame 
                achievements={allAchievements}
                personalAchievement={achievement}
                showPersonal={true}
              />
              <div className="mt-8">
                <HallOfFame 
                  achievements={allAchievements}
                />
              </div>
            </>
          );
        }
        return (
          <div className="text-center text-gray-400 py-8">
            <p>Complete all challenges to earn your certificate!</p>
            <div className="mt-8">
              <h2 className="text-2xl font-bold text-white mb-4">Current Champions</h2>
              <HallOfFame achievements={allAchievements} />
            </div>
          </div>
        );
      case 'blog':
        return (
          <div className="space-y-6">
            <article className="bg-gray-800 p-6 rounded-lg">
              <h2 className="text-2xl font-bold mb-4">Understanding Web Security</h2>
              <p className="text-gray-400">Learn about the latest vulnerabilities and how to protect against them.</p>
              <div className="mt-4">
                <a href="#" className="text-blue-400 hover:text-blue-300">Read more →</a>
              </div>
            </article>
            <article className="bg-gray-800 p-6 rounded-lg">
              <h2 className="text-2xl font-bold mb-4">Advanced Exploitation Techniques</h2>
              <p className="text-gray-400">Deep dive into modern exploitation methods and countermeasures.</p>
              <div className="mt-4">
                <a href="#" className="text-blue-400 hover:text-blue-300">Read more →</a>
              </div>
            </article>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <nav className="bg-gray-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Shield className="w-8 h-8 text-blue-500" />
              <span className="ml-2 text-xl font-bold">ToorSec CTF</span>
            </div>
            
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-300 hover:text-white"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => setCurrentPage('home')}
                className={`flex items-center space-x-2 ${currentPage === 'home' ? 'text-blue-400' : 'text-gray-300 hover:text-white'}`}
              >
                <Home className="w-5 h-5" />
                <span>Home</span>
              </button>
              <button
                onClick={() => setCurrentPage('ctf')}
                className={`flex items-center space-x-2 ${currentPage === 'ctf' ? 'text-blue-400' : 'text-gray-300 hover:text-white'}`}
              >
                <FlagIcon className="w-5 h-5" />
                <span>Challenges</span>
              </button>
              <button
                onClick={() => setCurrentPage('certificate')}
                className={`flex items-center space-x-2 ${currentPage === 'certificate' ? 'text-blue-400' : 'text-gray-300 hover:text-white'}`}
              >
                <Trophy className="w-5 h-5" />
                <span>Certificate</span>
              </button>
              <button
                onClick={() => setCurrentPage('blog')}
                className={`flex items-center space-x-2 ${currentPage === 'blog' ? 'text-blue-400' : 'text-gray-300 hover:text-white'}`}
              >
                <BookOpen className="w-5 h-5" />
                <span>Blog</span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 text-gray-300 hover:text-white"
              >
                <LogIn className="w-5 h-5" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button
                onClick={() => {
                  setCurrentPage('home');
                  setIsMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700 w-full text-left"
              >
                Home
              </button>
              <button
                onClick={() => {
                  setCurrentPage('ctf');
                  setIsMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700 w-full text-left"
              >
                Challenges
              </button>
              <button
                onClick={() => {
                  setCurrentPage('certificate');
                  setIsMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700 w-full text-left"
              >
                Certificate
              </button>
              <button
                onClick={() => {
                  setCurrentPage('blog');
                  setIsMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700 w-full text-left"
              >
                Blog
              </button>
              <button
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700 w-full text-left"
              >
                Logout
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="max-w-4xl mx-auto p-8">
        <div className="bg-gray-800 p-4 rounded-lg shadow-lg mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">IP: {userIP}</p>
              <p className="text-xs text-gray-500">Session expires in: {timeRemaining}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400">
                Solved: {flags.filter(f => f.solved).length} / {flags.length}
              </p>
              {userStats && (
                <p className="text-xs text-gray-500">
                  Total attempts: {userStats.attempts}
                </p>
              )}
            </div>
          </div>
        </div>

        {renderContent()}
      </main>

      <footer className="bg-gray-800 mt-auto py-6">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} ToorSec CTF. All rights reserved.
            </div>
            <div className="flex items-center space-x-2 text-gray-400 text-sm">
              <span>Created by</span>
              <span className="text-blue-400 font-semibold">Sami</span>
              <Shield className="w-4 h-4 text-blue-500" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;