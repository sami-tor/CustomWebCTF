import React, { useState } from 'react';
import { Flag } from '../types';
import { md5Hash } from '../utils/crypto';
import { flags } from '../utils/flags';
import { Lock, Unlock } from 'lucide-react';
import { ipTracker } from '../utils/ipTracker';

interface Props {
  flag: Flag;
  onSolve: (flagId: number) => void;
  isLocked: boolean;
}

export const FlagSubmission: React.FC<Props> = ({ flag, onSolve, isLocked }) => {
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const ip = await ipTracker.getClientIP();
    const flagData = flags.find(f => f.id === flag.id);
    
    if (isLocked) {
      setError('Access denied.');
      return;
    }

    // Rate limiting
    const stats = ipTracker.getStats(ip);
    const lastAttempt = stats?.lastAttempt || 0;
    const timeSinceLastAttempt = Date.now() - lastAttempt;
    
    if (timeSinceLastAttempt < 2000) { // 2 seconds cooldown
      setError('Rate limit exceeded. Please wait.');
      return;
    }

    setAttempts(prev => prev + 1);
    
    if (flagData && md5Hash(answer.trim()) === flagData.flag) {
      onSolve(flag.id);
      ipTracker.recordAttempt(ip, flag.id, true);
      setError('');
    } else {
      ipTracker.recordAttempt(ip, flag.id, false);
      setError('Invalid flag.');
    }
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg mb-4 ${isLocked ? 'opacity-50' : ''}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          {flag.solved ? (
            <Unlock className="text-green-500 mr-2" />
          ) : isLocked ? (
            <Lock className="text-gray-500 mr-2" />
          ) : (
            <Lock className="text-red-500 mr-2" />
          )}
          <h3 className="text-xl font-bold text-white">Level {flag.id}</h3>
        </div>
        {attempts > 0 && (
          <span className="text-sm text-gray-400">
            Attempts: {attempts}
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder={isLocked ? 'Access denied' : 'Enter flag'}
          className="w-full px-4 py-2 bg-gray-700 text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={flag.solved || isLocked}
        />
        
        {error && <p className="text-red-500 text-sm">{error}</p>}
        
        {!flag.solved && !isLocked && (
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
          >
            Submit
          </button>
        )}
      </form>
    </div>
  );
};