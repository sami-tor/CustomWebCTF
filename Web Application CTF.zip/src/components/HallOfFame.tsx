import React from 'react';
import { Trophy, Award, Calendar, Download } from 'lucide-react';
import { Achievement } from '../types';

interface Props {
  achievements: Achievement[];
  personalAchievement?: Achievement;
  showPersonal?: boolean;
}

export const HallOfFame: React.FC<Props> = ({ achievements, personalAchievement, showPersonal }) => {
  const generateCertificateHTML = (achievement: Achievement) => {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>ToorSec CTF Certificate</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
          <style>
            body {
              margin: 0;
              padding: 40px;
              background: #0a0c1b;
              color: #e2e8f0;
              font-family: 'JetBrains Mono', monospace;
            }
            .certificate {
              max-width: 1000px;
              margin: 0 auto;
              background: linear-gradient(145deg, #0f1225 0%, #1a1f35 100%);
              border: 2px solid #2563eb;
              border-radius: 16px;
              padding: 60px;
              box-shadow: 0 0 40px rgba(37, 99, 235, 0.2),
                         inset 0 0 20px rgba(37, 99, 235, 0.1);
              position: relative;
              overflow: hidden;
            }
            .certificate::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              right: 0;
              height: 5px;
              background: linear-gradient(90deg, #2563eb, #818cf8, #2563eb);
            }
            .header {
              text-align: center;
              margin-bottom: 40px;
            }
            .title {
              font-family: 'Orbitron', sans-serif;
              font-size: 42px;
              font-weight: 700;
              color: #ffffff;
              text-transform: uppercase;
              letter-spacing: 2px;
              margin: 0 0 20px;
              background: linear-gradient(90deg, #2563eb, #818cf8);
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;
            }
            .subtitle {
              font-family: 'Orbitron', sans-serif;
              font-size: 28px;
              color: #94a3b8;
              margin: 0;
              letter-spacing: 1px;
            }
            .content {
              text-align: center;
              margin: 40px 0;
              line-height: 1.8;
              font-size: 20px;
            }
            .username {
              font-family: 'Orbitron', sans-serif;
              font-size: 32px;
              font-weight: 700;
              color: #ffffff;
              margin: 20px 0;
              text-transform: uppercase;
              letter-spacing: 2px;
            }
            .details {
              margin-top: 40px;
              padding: 20px;
              background: rgba(37, 99, 235, 0.1);
              border-radius: 8px;
              font-size: 14px;
              color: #94a3b8;
            }
            .details-grid {
              display: grid;
              grid-template-columns: repeat(2, 1fr);
              gap: 20px;
            }
            .detail-item {
              display: flex;
              flex-direction: column;
              gap: 5px;
            }
            .detail-label {
              color: #64748b;
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 1px;
            }
            .detail-value {
              font-family: 'JetBrains Mono', monospace;
              color: #e2e8f0;
            }
            .signature {
              margin-top: 60px;
              text-align: right;
              border-top: 1px solid rgba(37, 99, 235, 0.3);
              padding-top: 20px;
            }
            .signature-name {
              font-family: 'Dancing Script', cursive;
              font-size: 28px;
              color: #818cf8;
              margin: 10px 0 5px;
            }
            .signature-title {
              font-size: 12px;
              color: #64748b;
              text-transform: uppercase;
              letter-spacing: 1px;
            }
            .watermark {
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              font-size: 200px;
              opacity: 0.03;
              pointer-events: none;
              font-family: 'Orbitron', sans-serif;
              white-space: nowrap;
            }
            .technologies {
              margin-top: 30px;
              font-size: 12px;
              color: #64748b;
              text-align: center;
            }
            .tech-list {
              display: flex;
              justify-content: center;
              gap: 20px;
              margin-top: 10px;
              flex-wrap: wrap;
            }
            .tech-item {
              background: rgba(37, 99, 235, 0.1);
              padding: 5px 15px;
              border-radius: 15px;
              color: #818cf8;
            }
          </style>
        </head>
        <body>
          <div class="certificate">
            <div class="watermark">TOORSEC</div>
            <div class="header">
              <h1 class="title">Certificate of Achievement</h1>
              <h2 class="subtitle">ToorSec CTF Challenge</h2>
            </div>
            
            <div class="content">
              This certifies that
              <div class="username">${achievement.username}</div>
              has successfully demonstrated exceptional skills in cybersecurity
              by completing all challenges in the ToorSec Capture The Flag competition
            </div>

            <div class="technologies">
              <div>DEMONSTRATED PROFICIENCY IN</div>
              <div class="tech-list">
                <span class="tech-item">Web Security</span>
                <span class="tech-item">Cryptography</span>
                <span class="tech-item">Binary Exploitation</span>
                <span class="tech-item">Reverse Engineering</span>
                <span class="tech-item">Network Security</span>
              </div>
            </div>

            <div class="details">
              <div class="details-grid">
                <div class="detail-item">
                  <span class="detail-label">Certificate ID</span>
                  <span class="detail-value">${achievement.certificateId}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">Completion Date</span>
                  <span class="detail-value">${new Date(achievement.completionDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}</span>
                </div>
              </div>
            </div>

            <div class="signature">
              <div class="signature-name">Sami</div>
              <div class="signature-title">Chief Security Officer, ToorSec</div>
            </div>
          </div>
        </body>
      </html>
    `;
  };

  const downloadCertificate = (achievement: Achievement) => {
    const certificateHTML = generateCertificateHTML(achievement);
    const blob = new Blob([certificateHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `toorsec-certificate-${achievement.username}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (showPersonal && personalAchievement) {
    return (
      <div className="max-w-2xl mx-auto bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <div className="p-8 text-center">
          <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-white mb-2">Congratulations!</h1>
          <p className="text-gray-400 mb-6">You've completed all challenges!</p>
          
          <div className="bg-gray-900/50 rounded-lg p-6 mb-8">
            <div className="flex items-center justify-center mb-4">
              <Award className="w-8 h-8 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold text-white">Your Achievement</h2>
            </div>
            
            <div className="space-y-4 text-left">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Username</span>
                <span className="text-white font-medium">{personalAchievement.username}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Certificate ID</span>
                <span className="text-white font-mono text-sm">{personalAchievement.certificateId}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Completion Date</span>
                <div className="flex items-center text-white">
                  <Calendar className="w-4 h-4 mr-2" />
                  {new Date(personalAchievement.completionDate).toLocaleDateString()}
                </div>
              </div>
            </div>

            <button
              onClick={() => downloadCertificate(personalAchievement)}
              className="mt-6 w-full flex items-center justify-center space-x-2 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Certificate</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-white">Hall of Fame</h1>
        <p className="text-gray-400 mt-2">Celebrating our CTF champions</p>
      </div>

      <div className="grid gap-4">
        {achievements.map((achievement) => (
          <div key={achievement.id} className="bg-gray-800 rounded-lg p-6 flex items-center justify-between">
            <div className="flex items-center">
              <Award className="w-8 h-8 text-blue-500 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-white">{achievement.username}</h3>
                <p className="text-sm text-gray-400">
                  Completed on {new Date(achievement.completionDate).toLocaleDateString()}
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-500/20 text-blue-400">
                All Challenges Completed
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};